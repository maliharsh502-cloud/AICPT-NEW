import { db } from "./db";
import {
  membershipApplications,
  type InsertMembershipApplication,
  type MembershipApplication
} from "@shared/schema";

export interface IStorage {
  createApplication(app: InsertMembershipApplication): Promise<MembershipApplication>;
}

export class DatabaseStorage implements IStorage {
  async createApplication(insertApp: InsertMembershipApplication): Promise<MembershipApplication> {
    const [app] = await db
      .insert(membershipApplications)
      .values(insertApp)
      .returning();
    return app;
  }
}

export const storage = new DatabaseStorage();
