import { pgTable, text, serial, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const membershipApplications = pgTable("membership_applications", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull(),
  dob: text("dob").notNull(),
  qualification: text("qualification").notNull(),
  institution: text("institution").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  city: text("city").notNull(),
  state: text("state").notNull(),
  membershipType: text("membership_type").notNull(), // 'Student' or 'Faculty'
  idProofUrl: text("id_proof_url"), // URL or path to uploaded file (optional for MVP)
  status: text("status").default("pending"), // pending, approved, rejected
});

export const insertMembershipApplicationSchema = createInsertSchema(membershipApplications).omit({ id: true, status: true });

export type MembershipApplication = typeof membershipApplications.$inferSelect;
export type InsertMembershipApplication = z.infer<typeof insertMembershipApplicationSchema>;
