import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { CheckCircle2, GraduationCap, ArrowLeft, Download } from "lucide-react";
import { motion } from "framer-motion";

export default function StudentMembership() {
  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      {/* Header */}
      <div className="bg-primary text-white py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Link href="/" className="inline-flex items-center text-primary-foreground/80 hover:text-white mb-6 transition-colors">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Home
          </Link>
          <div className="flex items-center gap-4 mb-6">
            <div className="p-3 bg-white/10 rounded-xl backdrop-blur-sm">
              <GraduationCap className="h-10 w-10 text-secondary" />
            </div>
            <h1 className="text-3xl md:text-5xl font-bold font-display">Student Membership</h1>
          </div>
          <p className="text-xl text-primary-foreground/90 max-w-2xl">
            Join a nationwide network of future pharmaceutical leaders. Gain recognition, knowledge, and career support.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 -mt-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-xl shadow-sm border border-border p-8"
            >
              <h2 className="text-2xl font-bold text-primary mb-6 font-display border-b pb-4">Eligibility Criteria</h2>
              <p className="text-muted-foreground mb-4">
                Students currently pursuing any of the following courses from a recognized institution are eligible to apply:
              </p>
              <div className="grid sm:grid-cols-2 gap-4">
                {["D.Pharm", "B.Pharm", "M.Pharm", "Pharm.D", "MBBS", "BAMS", "BHMS", "Allied Health Sciences"].map((course) => (
                  <div key={course} className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg border border-slate-100">
                    <div className="h-2 w-2 rounded-full bg-secondary"></div>
                    <span className="font-medium text-foreground">{course}</span>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-white rounded-xl shadow-sm border border-border p-8"
            >
              <h2 className="text-2xl font-bold text-primary mb-6 font-display border-b pb-4">Membership Benefits</h2>
              <div className="space-y-6">
                {[
                  { title: "National Recognition", desc: "Receive a prestigious membership certificate recognized across India." },
                  { title: "Academic Exposure", desc: "Access to exclusive webinars, seminars, and workshops led by industry experts." },
                  { title: "Networking Opportunities", desc: "Connect with peers, faculty, and industry professionals from across the country." },
                  { title: "Publication Support", desc: "Guidance and opportunities to publish research papers in reputed journals." },
                  { title: "Career Development", desc: "Resume building workshops, interview preparation, and placement assistance." },
                ].map((benefit, i) => (
                  <div key={i} className="flex gap-4">
                    <div className="mt-1">
                      <CheckCircle2 className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground text-lg">{benefit.title}</h3>
                      <p className="text-muted-foreground leading-relaxed">{benefit.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Sidebar CTA */}
          <div className="lg:col-span-1">
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-white rounded-xl shadow-lg border border-primary/20 p-6 sticky top-24"
            >
              <h3 className="text-xl font-bold text-primary mb-2 font-display">Membership Fee</h3>
              <div className="flex items-baseline gap-2 mb-6">
                <span className="text-4xl font-bold text-foreground">₹575</span>
                <span className="text-muted-foreground font-medium">/ 2 Years</span>
              </div>
              
              <div className="space-y-4">
                <Link href="/apply?type=Student" className="w-full block">
                  <Button size="lg" className="w-full bg-secondary hover:bg-secondary/90 text-slate-900 font-bold shadow-md">
                    Apply Now
                  </Button>
                </Link>
                <p className="text-xs text-center text-muted-foreground">
                  Secure payment processing. ID proof required during application.
                </p>
              </div>

              <div className="mt-8 pt-6 border-t">
                <h4 className="font-semibold mb-3 text-sm uppercase text-muted-foreground">Need Help?</h4>
                <div className="space-y-2 text-sm">
                  <p>Email: <a href="mailto:aicpt560@gmail.com" className="text-primary hover:underline">aicpt560@gmail.com</a></p>
                  <p>Phone: <a href="tel:+917058972437" className="text-primary hover:underline">+91 7058972437</a></p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
