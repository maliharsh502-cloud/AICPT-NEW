import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertMembershipApplicationSchema, type InsertMembershipApplication } from "@shared/schema";
import { useCreateApplication } from "@/hooks/use-applications";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Loader2, ArrowLeft, Upload } from "lucide-react";
import { useEffect } from "react";

export default function ApplicationForm() {
  const [location, setLocation] = useLocation();
  const searchParams = new URLSearchParams(window.location.search);
  const typeParam = searchParams.get("type");
  
  // Default to Student if invalid or missing
  const membershipType = typeParam === "Faculty" ? "Faculty" : "Student";
  const fee = membershipType === "Faculty" ? "₹1757" : "₹575";

  const { mutate, isPending } = useCreateApplication();

  const form = useForm<InsertMembershipApplication>({
    resolver: zodResolver(insertMembershipApplicationSchema),
    defaultValues: {
      membershipType,
      fullName: "",
      dob: "",
      qualification: "",
      institution: "",
      email: "",
      phone: "",
      city: "",
      state: "",
      idProofUrl: "", // Optional for now
    },
  });

  // Update form value if URL param changes
  useEffect(() => {
    form.setValue("membershipType", membershipType);
  }, [membershipType, form]);

  function onSubmit(data: InsertMembershipApplication) {
    mutate(data, {
      onSuccess: () => {
        form.reset();
        // Maybe redirect to a thank you page or show success state
      }
    });
  }

  return (
    <div className="min-h-screen bg-slate-50 py-12">
      <div className="container mx-auto px-4 max-w-3xl">
        <Button 
          variant="ghost" 
          onClick={() => setLocation("/")}
          className="mb-6 hover:bg-slate-200"
        >
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Home
        </Button>

        <Card className="shadow-lg border-t-4 border-t-primary">
          <CardHeader className="bg-white border-b pb-8">
            <CardTitle className="text-3xl font-display text-primary">
              {membershipType} Membership Application
            </CardTitle>
            <CardDescription className="text-lg mt-2">
              Please fill in your details accurately. Membership fee: <span className="font-bold text-foreground">{fee}</span> for 2 years.
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-8 bg-white">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                
                {/* Personal Details */}
                <div className="grid md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="fullName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Full Name (as per records)</FormLabel>
                        <FormControl>
                          <Input placeholder="John Doe" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="dob"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Date of Birth</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* Academic Details */}
                <div className="grid md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="qualification"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Qualification / Course</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select qualification" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="D.Pharm">D.Pharm</SelectItem>
                            <SelectItem value="B.Pharm">B.Pharm</SelectItem>
                            <SelectItem value="M.Pharm">M.Pharm</SelectItem>
                            <SelectItem value="Pharm.D">Pharm.D</SelectItem>
                            <SelectItem value="PhD">PhD</SelectItem>
                            <SelectItem value="MBBS">MBBS</SelectItem>
                            <SelectItem value="Other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="institution"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Institution / College Name</FormLabel>
                        <FormControl>
                          <Input placeholder="University of Pharmacy..." {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* Contact Details */}
                <div className="grid md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email Address</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="john@example.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone Number</FormLabel>
                        <FormControl>
                          <Input type="tel" placeholder="+91 9876543210" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="city"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>City</FormLabel>
                        <FormControl>
                          <Input placeholder="Mumbai" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="state"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>State</FormLabel>
                        <FormControl>
                          <Input placeholder="Maharashtra" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* ID Proof - Simulated for now */}
                <div className="p-4 bg-slate-50 border border-dashed border-slate-300 rounded-lg">
                  <FormLabel className="mb-2 block">Upload ID Proof (College ID / Government ID)</FormLabel>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <Button type="button" variant="outline" size="sm" onClick={() => alert("File upload will be implemented with backend integration.")}>
                      <Upload className="h-4 w-4 mr-2" /> Select File
                    </Button>
                    <span>No file selected (Optional for demo)</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">Supported formats: JPG, PNG, PDF (Max 2MB)</p>
                </div>

                <div className="pt-6 border-t flex justify-end">
                  <Button 
                    type="submit" 
                    size="lg" 
                    className="w-full md:w-auto bg-primary hover:bg-primary/90 text-white min-w-[200px]"
                    disabled={isPending}
                  >
                    {isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Submitting...
                      </>
                    ) : (
                      "Submit Application"
                    )}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
