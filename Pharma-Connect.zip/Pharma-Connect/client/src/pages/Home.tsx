import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { GraduationCap, Users, BookOpen, Award, ArrowRight, CheckCircle2 } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary via-blue-900 to-slate-900 text-white py-24 lg:py-32">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&q=80')] opacity-10 bg-cover bg-center mix-blend-overlay"></div>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-4xl mx-auto space-y-8"
          >
            <div className="inline-block px-4 py-1.5 rounded-full border border-secondary/50 bg-secondary/10 text-secondary text-sm font-semibold tracking-wide uppercase mb-4">
              Official National Academic Body
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-7xl font-bold font-display tracking-tight text-white drop-shadow-lg">
              Empowering the Next Generation of <span className="text-secondary">Pharmaceutical Professionals</span>
            </h1>
            <p className="text-lg md:text-xl text-slate-200 max-w-2xl mx-auto leading-relaxed">
              Join the premier national consortium dedicated to excellence in pharmaceutical education, research, and professional development.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-8">
              <Link href="/apply?type=Student">
                <Button size="lg" className="h-14 px-8 text-lg font-semibold bg-secondary hover:bg-secondary/90 text-slate-900 shadow-xl shadow-secondary/20 hover:-translate-y-1 transition-all">
                  Student Membership
                </Button>
              </Link>
              <Link href="/apply?type=Faculty">
                <Button size="lg" variant="outline" className="h-14 px-8 text-lg font-semibold border-white/30 text-white hover:bg-white/10 hover:border-white shadow-lg backdrop-blur-sm hover:-translate-y-1 transition-all">
                  Faculty Membership
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* About Preview */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="absolute -inset-4 bg-secondary/10 rounded-2xl transform -rotate-2"></div>
              {/* laboratory research science */}
              <img 
                src="https://pixabay.com/get/gb13269c9e88cb65596640ba6238cb67ae7773197584cd7178b1ea8ebbf90c7375f10f2e9f67f587e6eca9e44792fb56390d61bcc451f90ddf0ba08e7fe701fcd_1280.jpg" 
                alt="Pharmaceutical Research" 
                className="relative rounded-lg shadow-2xl border border-border"
              />
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-6"
            >
              <h2 className="text-3xl font-bold text-primary font-display">Excellence in Pharmaceutical Education</h2>
              <p className="text-muted-foreground leading-relaxed text-lg">
                The All India Consortium of Pharmaceutical Training (AICPT) is committed to bridging the gap between academic learning and industry requirements. We provide a platform for students and faculty to enhance their skills, network with peers, and stay updated with the latest advancements in healthcare and pharmacy.
              </p>
              <ul className="space-y-3">
                {[
                  "National Recognition & Certification",
                  "Industry-Academic Collaboration",
                  "Continuous Professional Development",
                  "Research & Publication Support"
                ].map((item) => (
                  <li key={item} className="flex items-center gap-3 text-foreground font-medium">
                    <CheckCircle2 className="h-5 w-5 text-secondary" />
                    {item}
                  </li>
                ))}
              </ul>
              <Link href="/about">
                <Button variant="link" className="px-0 text-primary font-semibold text-lg group">
                  Learn more about our vision <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Membership Cards */}
      <section className="py-24 bg-slate-50 border-y border-border/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold text-primary mb-4 font-display">Membership Opportunities</h2>
            <p className="text-muted-foreground text-lg">Choose the membership plan that suits your academic journey. Unlock exclusive benefits and national recognition.</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 lg:gap-12 max-w-5xl mx-auto">
            {/* Student Card */}
            <motion.div 
              whileHover={{ y: -8 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <Card className="h-full flex flex-col border-t-4 border-t-primary shadow-lg hover:shadow-xl transition-all">
                <CardHeader className="text-center pb-8 border-b bg-primary/5">
                  <div className="mx-auto w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-sm mb-4">
                    <GraduationCap className="h-8 w-8 text-primary" />
                  </div>
                  <CardTitle className="text-2xl font-bold text-primary font-display">Student Membership</CardTitle>
                  <CardDescription className="text-base mt-2">For aspiring professionals</CardDescription>
                  <div className="mt-4">
                    <span className="text-4xl font-bold text-foreground">₹575</span>
                    <span className="text-muted-foreground font-medium"> / 2 Years</span>
                  </div>
                </CardHeader>
                <CardContent className="flex-1 pt-8">
                  <h4 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-4">Eligibility</h4>
                  <p className="text-sm mb-6 font-medium">D.Pharm, B.Pharm, M.Pharm, Pharm.D, MBBS, BAMS, BHMS & Allied Health</p>
                  
                  <h4 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-4">Key Benefits</h4>
                  <ul className="space-y-3 mb-8">
                    <li className="flex items-start gap-3 text-sm"><CheckCircle2 className="h-5 w-5 text-green-600 shrink-0" /> National Level Certification</li>
                    <li className="flex items-start gap-3 text-sm"><CheckCircle2 className="h-5 w-5 text-green-600 shrink-0" /> Access to Webinars & Workshops</li>
                    <li className="flex items-start gap-3 text-sm"><CheckCircle2 className="h-5 w-5 text-green-600 shrink-0" /> Career Guidance & Networking</li>
                  </ul>
                </CardContent>
                <CardFooter>
                  <Link href="/student-membership" className="w-full">
                    <Button className="w-full bg-primary hover:bg-primary/90">View Details & Apply</Button>
                  </Link>
                </CardFooter>
              </Card>
            </motion.div>

            {/* Faculty Card */}
            <motion.div 
              whileHover={{ y: -8 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <Card className="h-full flex flex-col border-t-4 border-t-secondary shadow-lg hover:shadow-xl transition-all">
                <CardHeader className="text-center pb-8 border-b bg-secondary/5">
                  <div className="mx-auto w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-sm mb-4">
                    <Award className="h-8 w-8 text-secondary" />
                  </div>
                  <CardTitle className="text-2xl font-bold text-primary font-display">Faculty Membership</CardTitle>
                  <CardDescription className="text-base mt-2">For academic leaders</CardDescription>
                  <div className="mt-4">
                    <span className="text-4xl font-bold text-foreground">₹1757</span>
                    <span className="text-muted-foreground font-medium"> / 2 Years</span>
                  </div>
                </CardHeader>
                <CardContent className="flex-1 pt-8">
                  <h4 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-4">Eligibility</h4>
                  <p className="text-sm mb-6 font-medium">Assistant Professor, Associate Professor, Professor (Min. M.Pharm)</p>
                  
                  <h4 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-4">Key Benefits</h4>
                  <ul className="space-y-3 mb-8">
                    <li className="flex items-start gap-3 text-sm"><CheckCircle2 className="h-5 w-5 text-green-600 shrink-0" /> Official AICPT Membership Certificate</li>
                    <li className="flex items-start gap-3 text-sm"><CheckCircle2 className="h-5 w-5 text-green-600 shrink-0" /> Priority Access to FDPs</li>
                    <li className="flex items-start gap-3 text-sm"><CheckCircle2 className="h-5 w-5 text-green-600 shrink-0" /> Research Collaboration Opportunities</li>
                  </ul>
                </CardContent>
                <CardFooter>
                  <Link href="/faculty-membership" className="w-full">
                    <Button className="w-full bg-secondary hover:bg-secondary/90 text-slate-900 font-semibold">View Details & Apply</Button>
                  </Link>
                </CardFooter>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats/Trust Section */}
      <section className="py-16 bg-primary text-white">
        <div className="container mx-auto px-4 text-center">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { label: "Members", value: "5000+" },
              { label: "Institutions", value: "200+" },
              { label: "Workshops", value: "50+" },
              { label: "Years of Excellence", value: "10+" }
            ].map((stat, i) => (
              <div key={i} className="space-y-2">
                <div className="text-4xl font-bold font-display">{stat.value}</div>
                <div className="text-primary-foreground/80 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
