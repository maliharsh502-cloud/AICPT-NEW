import { Link } from "wouter";
import { ArrowLeft, Mail, Phone, MapPin, Clock } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export default function Contact() {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="bg-primary text-white py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Link href="/" className="inline-flex items-center text-primary-foreground/80 hover:text-white mb-6 transition-colors">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Home
          </Link>
          <h1 className="text-4xl md:text-5xl font-bold font-display mb-4">Contact Us</h1>
          <p className="text-xl text-primary-foreground/90 max-w-2xl">
            Have questions? We are here to help you with your membership and inquiries.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 -mt-10">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Contact Info Cards */}
          <div className="space-y-6">
            <Card className="shadow-md">
              <CardContent className="p-6 flex items-start gap-4">
                <div className="bg-blue-100 p-3 rounded-full">
                  <Phone className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-primary mb-1">Phone</h3>
                  <p className="text-muted-foreground mb-2">Mon-Sat from 10am to 6pm</p>
                  <a href="tel:+917058972437" className="text-lg font-semibold hover:text-secondary transition-colors">
                    +91 7058972437
                  </a>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-md">
              <CardContent className="p-6 flex items-start gap-4">
                <div className="bg-amber-100 p-3 rounded-full">
                  <Mail className="h-6 w-6 text-secondary-foreground" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-primary mb-1">Email</h3>
                  <p className="text-muted-foreground mb-2">For general inquiries</p>
                  <div className="flex flex-col gap-1">
                    <a href="mailto:aicpt560@gmail.com" className="font-medium hover:text-secondary transition-colors">aicpt560@gmail.com</a>
                    <a href="mailto:office@aicpt.online" className="font-medium hover:text-secondary transition-colors">office@aicpt.online</a>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-md">
              <CardContent className="p-6 flex items-start gap-4">
                <div className="bg-slate-100 p-3 rounded-full">
                  <MapPin className="h-6 w-6 text-slate-700" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-primary mb-1">Office</h3>
                  <p className="text-muted-foreground">
                    Maharashtra, India
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Map / Image */}
          <div className="lg:col-span-2">
            <Card className="h-full shadow-md overflow-hidden min-h-[400px]">
              {/* Using an image as a placeholder for a map or office photo */}
              {/* office building corporate */}
              <div className="h-full w-full bg-[url('https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80')] bg-cover bg-center relative">
                <div className="absolute inset-0 bg-slate-900/40 flex items-center justify-center">
                  <div className="bg-white/90 backdrop-blur p-8 rounded-xl shadow-2xl max-w-md text-center">
                    <h3 className="text-2xl font-bold text-primary font-display mb-2">Visit Our Headquarters</h3>
                    <p className="text-muted-foreground mb-4">We are always ready to welcome our members and partners.</p>
                    <div className="flex items-center justify-center gap-2 text-sm font-medium text-slate-600">
                       <Clock className="h-4 w-4" /> Office Hours: 10:00 AM - 6:00 PM
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
