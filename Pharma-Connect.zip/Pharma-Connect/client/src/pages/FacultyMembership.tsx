import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Award, ArrowLeft, Star } from "lucide-react";
import { motion } from "framer-motion";

export default function FacultyMembership() {
  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      {/* Header */}
      <div className="bg-slate-900 text-white py-16 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/3 h-full bg-secondary/10 -skew-x-12 transform translate-x-20"></div>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <Link href="/" className="inline-flex items-center text-slate-300 hover:text-white mb-6 transition-colors">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Home
          </Link>
          <div className="flex items-center gap-4 mb-6">
            <div className="p-3 bg-secondary/20 rounded-xl backdrop-blur-sm border border-secondary/30">
              <Award className="h-10 w-10 text-secondary" />
            </div>
            <h1 className="text-3xl md:text-5xl font-bold font-display">Faculty Membership</h1>
          </div>
          <p className="text-xl text-slate-300 max-w-2xl">
            Elevate your academic career. Join a distinguished community of educators and researchers.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 -mt-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-xl shadow-sm border border-border p-8"
            >
              <h2 className="text-2xl font-bold text-primary mb-6 font-display border-b pb-4">Eligibility Criteria</h2>
              <div className="flex items-start gap-4 mb-6 p-4 bg-blue-50 border border-blue-100 rounded-lg">
                <Star className="h-6 w-6 text-primary mt-1" />
                <div>
                  <h3 className="font-bold text-primary">Minimum Qualification</h3>
                  <p className="text-blue-700">M.Pharm or equivalent master's degree in relevant field.</p>
                </div>
              </div>
              <p className="text-muted-foreground mb-4">
                Open to academic professionals holding the following positions:
              </p>
              <div className="grid sm:grid-cols-2 gap-4">
                {["Assistant Professor", "Associate Professor", "Professor", "HOD / Principal"].map((role) => (
                  <div key={role} className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg border border-slate-100">
                    <div className="h-2 w-2 rounded-full bg-primary"></div>
                    <span className="font-medium text-foreground">{role}</span>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-white rounded-xl shadow-sm border border-border p-8"
            >
              <h2 className="text-2xl font-bold text-primary mb-6 font-display border-b pb-4">Exclusive Benefits</h2>
              <div className="space-y-6">
                {[
                  { title: "Professional Recognition", desc: "Official AICPT Faculty Membership Certificate and Faculty ID Card." },
                  { title: "Priority Access", desc: "Early registration and special discounts for Faculty Development Programs (FDPs) and Conferences." },
                  { title: "Research Collaboration", desc: "Opportunities to collaborate on multi-institutional research projects and grants." },
                  { title: "Leadership Roles", desc: "Eligibility to chair sessions, judge competitions, and lead regional chapters." },
                  { title: "Resource Access", desc: "Access to AICPT digital library resources and teaching aids." },
                ].map((benefit, i) => (
                  <div key={i} className="flex gap-4">
                    <div className="mt-1">
                      <CheckCircle2 className="h-6 w-6 text-secondary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground text-lg">{benefit.title}</h3>
                      <p className="text-muted-foreground leading-relaxed">{benefit.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Sidebar CTA */}
          <div className="lg:col-span-1">
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-white rounded-xl shadow-lg border-t-4 border-t-secondary p-6 sticky top-24"
            >
              <h3 className="text-xl font-bold text-primary mb-2 font-display">Membership Fee</h3>
              <div className="flex items-baseline gap-2 mb-6">
                <span className="text-4xl font-bold text-foreground">₹1757</span>
                <span className="text-muted-foreground font-medium">/ 2 Years</span>
              </div>
              
              <div className="space-y-4">
                <Link href="/apply?type=Faculty" className="w-full block">
                  <Button size="lg" className="w-full bg-primary hover:bg-primary/90 text-white font-bold shadow-md">
                    Apply Now
                  </Button>
                </Link>
                <p className="text-xs text-center text-muted-foreground">
                  Secure payment processing. Professional proof required.
                </p>
              </div>

              <div className="mt-8 pt-6 border-t">
                <h4 className="font-semibold mb-3 text-sm uppercase text-muted-foreground">Contact Office</h4>
                <div className="space-y-2 text-sm">
                  <p>Email: <a href="mailto:office@aicpt.online" className="text-primary hover:underline">office@aicpt.online</a></p>
                  <p>Phone: <a href="tel:+917058972437" className="text-primary hover:underline">+91 7058972437</a></p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
