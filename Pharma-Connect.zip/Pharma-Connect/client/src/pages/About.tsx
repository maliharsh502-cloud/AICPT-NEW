import { Link } from "wouter";
import { ArrowLeft, Target, Eye, Globe } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";

export default function About() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-primary text-white py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Link href="/" className="inline-flex items-center text-primary-foreground/80 hover:text-white mb-6 transition-colors">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Home
          </Link>
          <h1 className="text-4xl md:text-5xl font-bold font-display mb-4">About AICPT</h1>
          <p className="text-xl text-primary-foreground/90 max-w-2xl">
            A premier national body dedicated to excellence in pharmaceutical education, training, and research.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid lg:grid-cols-2 gap-12 mb-20">
          <div className="space-y-6">
            <h2 className="text-3xl font-bold text-primary font-display">Who We Are</h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              The All India Consortium of Pharmaceutical Training (AICPT) was established with a singular purpose: to elevate the standards of pharmaceutical education in India. We act as a bridge between academic institutions and the pharmaceutical industry, ensuring that students are industry-ready and faculty members are equipped with the latest pedagogical and research skills.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed">
              With a network spanning across states and institutions, AICPT provides a collaborative platform for knowledge exchange, standardization of training protocols, and professional growth.
            </p>
          </div>
          <div className="relative">
             {/* pharmacy students in lab */}
            <img 
              src="https://pixabay.com/get/g49e19d79b78115d22793d67c5b5f47f5d2829a8a728db79cada417af070bfae788c6fbe1088d2f5d5435b04306521efd9d06128eaa13a2f252d42cb0e9c8a545_1280.jpg" 
              alt="Pharmacy Students" 
              className="rounded-lg shadow-xl border border-border"
            />
            <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-lg shadow-lg border border-border max-w-xs hidden md:block">
              <div className="text-4xl font-bold text-secondary mb-1">10+</div>
              <div className="text-sm font-medium text-muted-foreground">Years of shaping careers</div>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-20">
          <Card className="bg-blue-50 border-blue-100 hover:shadow-md transition-shadow">
            <CardContent className="pt-6">
              <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <Target className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold text-primary mb-3">Our Mission</h3>
              <p className="text-muted-foreground">
                To provide high-quality training, facilitate cutting-edge research, and foster professional development among pharmacy students and faculty members across India.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-amber-50 border-amber-100 hover:shadow-md transition-shadow">
            <CardContent className="pt-6">
              <div className="h-12 w-12 bg-secondary/10 rounded-lg flex items-center justify-center mb-4">
                <Eye className="h-6 w-6 text-secondary" />
              </div>
              <h3 className="text-xl font-bold text-primary mb-3">Our Vision</h3>
              <p className="text-muted-foreground">
                To be the leading national consortium recognized globally for excellence in pharmaceutical education and for producing competent healthcare professionals.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-50 border-slate-100 hover:shadow-md transition-shadow">
            <CardContent className="pt-6">
              <div className="h-12 w-12 bg-slate-200 rounded-lg flex items-center justify-center mb-4">
                <Globe className="h-6 w-6 text-slate-700" />
              </div>
              <h3 className="text-xl font-bold text-primary mb-3">Our Reach</h3>
              <p className="text-muted-foreground">
                Connecting over 200 institutions and thousands of members into a cohesive ecosystem of learning and innovation.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
