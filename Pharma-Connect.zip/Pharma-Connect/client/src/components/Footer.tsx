import { Link } from "wouter";
import { Mail, Phone, MapPin, ExternalLink } from "lucide-react";
import aicptLogo from "@assets/WhatsApp_Image_2025-12-31_at_5.43.09_PM_1767191999649.jpeg";

export function Footer() {
  return (
    <footer className="bg-slate-900 text-slate-200 border-t border-slate-800">
      <div className="container mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <img 
                src={aicptLogo} 
                alt="AICPT Logo" 
                className="h-12 w-auto object-contain bg-white rounded p-1" 
              />
              <span className="text-xl font-bold font-display text-white">AICPT</span>
            </div>
            <p className="text-sm text-slate-400 leading-relaxed max-w-xs">
              Empowering the next generation of pharmaceutical professionals through education, training, and excellence.
            </p>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-white mb-4 font-display">Quick Links</h3>
            <ul className="space-y-3 text-sm">
              <li><Link href="/" className="hover:text-secondary transition-colors flex items-center gap-2">Home</Link></li>
              <li><Link href="/about" className="hover:text-secondary transition-colors">About Us</Link></li>
              <li><Link href="/student-membership" className="hover:text-secondary transition-colors">Student Membership</Link></li>
              <li><Link href="/faculty-membership" className="hover:text-secondary transition-colors">Faculty Membership</Link></li>
              <li><Link href="/apply?type=Student" className="hover:text-secondary transition-colors">Apply Online</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-white mb-4 font-display">Contact Us</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-3">
                <Mail className="h-5 w-5 text-secondary shrink-0" />
                <div className="flex flex-col">
                  <a href="mailto:aicpt560@gmail.com" className="hover:text-white">aicpt560@gmail.com</a>
                  <a href="mailto:office@aicpt.online" className="hover:text-white text-xs text-slate-400">CC: office@aicpt.online</a>
                </div>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-secondary shrink-0" />
                <a href="tel:+917058972437" className="hover:text-white">+91 7058972437</a>
              </li>
              <li className="flex items-center gap-3">
                <MapPin className="h-5 w-5 text-secondary shrink-0" />
                <span>Maharashtra, India</span>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-white mb-4 font-display">Legal</h3>
            <ul className="space-y-3 text-sm">
              <li><a href="#" className="hover:text-secondary transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-secondary transition-colors">Terms of Service</a></li>
              <li><a href="#" className="hover:text-secondary transition-colors">Cookie Policy</a></li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-slate-800 text-center text-sm text-slate-500">
          <p>© {new Date().getFullYear()} All India Consortium of Pharmaceutical Training (AICPT). All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
