import { Link, useLocation } from "wouter";
import aicptLogo from "@assets/WhatsApp_Image_2025-12-31_at_5.43.09_PM_1767191999649.jpeg";
import { Menu, X, GraduationCap } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const NAV_ITEMS = [
  { label: "Home", href: "/" },
  { label: "About", href: "/about" },
  { label: "Student Membership", href: "/student-membership" },
  { label: "Faculty Membership", href: "/faculty-membership" },
  { label: "Contact", href: "/contact" },
];

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [location] = useLocation();

  return (
    <nav className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 shadow-sm">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-20 items-center justify-between">
          <Link href="/" className="flex items-center gap-3 hover:opacity-90 transition-opacity">
            <img 
              src={aicptLogo} 
              alt="AICPT Logo" 
              className="h-12 w-auto object-contain rounded-sm" 
            />
            <div className="hidden md:flex flex-col">
              <span className="text-xl font-bold tracking-tight text-primary font-display leading-tight">
                AICPT
              </span>
              <span className="text-[10px] text-muted-foreground uppercase tracking-widest font-semibold">
                Consortium of Pharmaceutical Training
              </span>
            </div>
          </Link>

          <div className="hidden lg:flex items-center gap-6">
            {NAV_ITEMS.map((item) => (
              <Link 
                key={item.href} 
                href={item.href}
                className={cn(
                  "text-sm font-medium transition-colors hover:text-primary relative group py-2",
                  location === item.href ? "text-primary" : "text-muted-foreground"
                )}
              >
                {item.label}
                <span className={cn(
                  "absolute bottom-0 left-0 w-full h-0.5 bg-secondary transform transition-transform origin-left duration-200",
                  location === item.href ? "scale-x-100" : "scale-x-0 group-hover:scale-x-100"
                )} />
              </Link>
            ))}
            <Link href="/apply?type=Student">
              <Button size="sm" className="bg-primary hover:bg-primary/90 text-white font-semibold shadow-md shadow-primary/20">
                Apply Now
              </Button>
            </Link>
          </div>

          <button
            className="lg:hidden p-2 text-primary"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="lg:hidden bg-background border-b animate-in slide-in-from-top-2">
          <div className="space-y-1 px-4 py-4">
            {NAV_ITEMS.map((item) => (
              <Link 
                key={item.href} 
                href={item.href}
                onClick={() => setIsOpen(false)}
                className={cn(
                  "block px-3 py-3 rounded-md text-base font-medium transition-colors",
                  location === item.href 
                    ? "bg-primary/10 text-primary font-semibold" 
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                )}
              >
                {item.label}
              </Link>
            ))}
            <div className="pt-4 border-t mt-2">
              <Link href="/apply?type=Student" onClick={() => setIsOpen(false)}>
                <Button className="w-full bg-primary hover:bg-primary/90">Apply Membership</Button>
              </Link>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
