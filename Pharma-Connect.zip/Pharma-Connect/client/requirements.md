## Packages
framer-motion | Page transitions and reveal animations
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind CSS classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["var(--font-sans)"],
  serif: ["var(--font-serif)"],
  display: ["var(--font-display)"],
}
API expects POST /api/applications for form submissions.
ID Proof upload is simulated for now (text input or simple file input without actual upload logic until backend supports multipart).
